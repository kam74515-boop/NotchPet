#!/usr/bin/env node
try{process.stdin.resume();process.stdin.on("data",()=>{});}catch(e){}
process.exit(0);
