#!/usr/bin/env node
'use strict';

const crypto = require('crypto');
const net = require('net');
const os = require('os');
const path = require('path');

const socketPath = path.join(os.homedir(), '.notchpet', 'codex-app-server-backend.sock');
const requestId = process.argv[2] === 'number' ? Number(process.argv[3]) : process.argv[3];
let answers;
try { answers = JSON.parse(process.argv[4]); } catch { process.exit(2); }
if (requestId == null || !answers || typeof answers !== 'object') process.exit(2);

let buffer = Buffer.alloc(0), ready = false, initialized = false;
const socket = net.createConnection(socketPath, () => {
  const key = crypto.randomBytes(16).toString('base64');
  socket.write(`GET /rpc HTTP/1.1\r\nHost: localhost\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Key: ${key}\r\nSec-WebSocket-Version: 13\r\n\r\n`);
});

function send(message) {
  const payload = Buffer.from(JSON.stringify(message));
  const mask = crypto.randomBytes(4);
  const header = Buffer.alloc(payload.length < 126 ? 6 : 8);
  header[0] = 0x81;
  if (payload.length < 126) { header[1] = 0x80 | payload.length; mask.copy(header, 2); }
  else { header[1] = 0xfe; header.writeUInt16BE(payload.length, 2); mask.copy(header, 4); }
  const encoded = Buffer.alloc(payload.length);
  for (let i = 0; i < payload.length; i += 1) encoded[i] = payload[i] ^ mask[i % 4];
  socket.write(Buffer.concat([header, encoded]));
}

function consumeFrames() {
  while (buffer.length >= 2) {
    let length = buffer[1] & 0x7f, offset = 2;
    if (length === 126) { if (buffer.length < 4) return; length = buffer.readUInt16BE(2); offset = 4; }
    else if (length === 127) { if (buffer.length < 10) return; length = Number(buffer.readBigUInt64BE(2)); offset = 10; }
    if (buffer.length < offset + length) return;
    const payload = buffer.subarray(offset, offset + length); buffer = buffer.subarray(offset + length);
    if ((payload.length === 0) || initialized) continue;
    let message; try { message = JSON.parse(payload.toString('utf8')); } catch { continue; }
    if (message.id !== 'notchpet-initialize') continue;
    initialized = true;
    send({ id: requestId, result: { answers: Object.fromEntries(
      Object.entries(answers).map(([id, value]) => [id, { answers: Array.isArray(value) ? value : [String(value)] }])
    ) } });
    setTimeout(() => process.exit(0), 250);
  }
}

socket.on('data', data => {
  buffer = Buffer.concat([buffer, data]);
  if (!ready) {
    const end = buffer.indexOf('\r\n\r\n'); if (end < 0) return;
    buffer = buffer.subarray(end + 4); ready = true;
    send({ id: 'notchpet-initialize', method: 'initialize', params: {
      clientInfo: { name: 'notchpet', title: 'NotchPet', version: '1' }, capabilities: { experimentalApi: true },
    } });
  }
  consumeFrames();
});
socket.on('error', () => process.exit(1));
setTimeout(() => process.exit(1), 5000);
