#!/usr/bin/env node
'use strict';

// Makes the Codex desktop app's shared app-server observable to NotchPet. The proxy is byte-for-
// byte transparent; it only reads JSON websocket frames so the notch can retain the server request
// id that is required to answer request_user_input from a second client connection.

const fs = require('fs');
const http = require('http');
const net = require('net');
const os = require('os');
const path = require('path');
const { spawn, spawnSync } = require('child_process');

const home = os.homedir();
const controlDir = path.join(home, '.codex', 'app-server-control');
const frontSocket = path.join(controlDir, 'app-server-control.sock');
const backendSocket = path.join(home, '.notchpet', 'codex-app-server-backend.sock');
const runtimePath = path.join(home, '.notchpet', 'runtime.json');
const codexCandidates = [
  '/Applications/ChatGPT.app/Contents/Resources/codex',
  '/Applications/Codex.app/Contents/Resources/codex',
];

function removeSocket(file) {
  try { fs.unlinkSync(file); } catch (error) {
    if (error.code !== 'ENOENT') throw error;
  }
}

function runtimePort() {
  try { return Number(JSON.parse(fs.readFileSync(runtimePath, 'utf8')).port) || 24333; }
  catch { return 24333; }
}

function postState(body) {
  const data = Buffer.from(JSON.stringify(body));
  const req = http.request({ hostname: '127.0.0.1', port: runtimePort(), path: '/state', method: 'POST',
    headers: { 'content-type': 'application/json', 'content-length': data.length } });
  req.on('error', () => {});
  req.end(data);
}

class FrameDecoder {
  constructor(onJSON) { this.buffer = Buffer.alloc(0); this.fragment = null; this.onJSON = onJSON; }
  push(data) {
    this.buffer = Buffer.concat([this.buffer, data]);
    while (this.buffer.length >= 2) {
      const first = this.buffer[0];
      const second = this.buffer[1];
      const opcode = first & 0x0f;
      const final = (first & 0x80) !== 0;
      const masked = (second & 0x80) !== 0;
      let length = second & 0x7f;
      let offset = 2;
      if (length === 126) {
        if (this.buffer.length < 4) return;
        length = this.buffer.readUInt16BE(2); offset = 4;
      } else if (length === 127) {
        if (this.buffer.length < 10) return;
        length = Number(this.buffer.readBigUInt64BE(2)); offset = 10;
      }
      const maskBytes = masked ? 4 : 0;
      if (this.buffer.length < offset + maskBytes + length) return;
      const mask = masked ? this.buffer.subarray(offset, offset + 4) : null;
      offset += maskBytes;
      const payload = Buffer.from(this.buffer.subarray(offset, offset + length));
      this.buffer = this.buffer.subarray(offset + length);
      if (mask) for (let i = 0; i < payload.length; i += 1) payload[i] ^= mask[i % 4];
      if (opcode === 1) this.fragment = payload;
      else if (opcode === 0 && this.fragment) this.fragment = Buffer.concat([this.fragment, payload]);
      else continue;
      if (!final) continue;
      const text = this.fragment.toString('utf8');
      this.fragment = null;
      try { this.onJSON(JSON.parse(text)); } catch {}
    }
  }
}

const pending = new Map();
const requestKey = value => `${typeof value}:${String(value)}`;

function observeServerMessage(message) {
  if (message?.method !== 'item/tool/requestUserInput' || message.id == null) return;
  const params = message.params || {};
  const itemId = typeof params.itemId === 'string' ? params.itemId : '';
  const threadId = typeof params.threadId === 'string' ? params.threadId : '';
  if (!itemId || !threadId || !Array.isArray(params.questions)) return;
  pending.set(requestKey(message.id), { threadId, itemId });
  postState({
    event: 'CodexUserInputRequest', state: 'notification', agent_id: 'codex', source: 'codex-app-server',
    session_id: `codex:${threadId}`, headless: false,
    codex_user_input: {
      phase: 'request', call_id: itemId, request_id: String(message.id), request_id_type: typeof message.id,
      questions: params.questions,
    },
  });
}

function observeClientMessage(message) {
  if (message?.id == null || message.method != null || message.result == null) return;
  const match = pending.get(requestKey(message.id));
  if (!match) return;
  pending.delete(requestKey(message.id));
  postState({
    event: 'CodexUserInputResolved', state: 'working', agent_id: 'codex', source: 'codex-app-server',
    session_id: `codex:${match.threadId}`,
    codex_user_input: { phase: 'resolved', call_id: match.itemId, request_id: String(message.id),
      request_id_type: typeof message.id, questions: [] },
  });
}

function proxyConnection(client) {
  const backend = net.createConnection(backendSocket);
  const fromServer = new FrameDecoder(observeServerMessage);
  const fromClient = new FrameDecoder(observeClientMessage);
  let requestBuffer = Buffer.alloc(0);
  let responseBuffer = Buffer.alloc(0);
  let upgraded = false;
  let serverUpgraded = false;

  client.on('data', data => {
    if (upgraded) { fromClient.push(data); backend.write(data); return; }
    requestBuffer = Buffer.concat([requestBuffer, data]);
    const end = requestBuffer.indexOf('\r\n\r\n');
    if (end < 0) return;
    const header = requestBuffer.subarray(0, end + 4).toString('utf8')
      .split('\r\n').filter(line => !/^sec-websocket-extensions:/i.test(line)).join('\r\n');
    const rest = requestBuffer.subarray(end + 4);
    backend.write(Buffer.concat([Buffer.from(header), rest]));
    if (rest.length) fromClient.push(rest);
    upgraded = true;
    requestBuffer = Buffer.alloc(0);
  });
  backend.on('data', data => {
    client.write(data);
    if (serverUpgraded) { fromServer.push(data); return; }
    responseBuffer = Buffer.concat([responseBuffer, data]);
    const end = responseBuffer.indexOf('\r\n\r\n');
    if (end < 0) return;
    const rest = responseBuffer.subarray(end + 4);
    serverUpgraded = true;
    responseBuffer = Buffer.alloc(0);
    if (rest.length) fromServer.push(rest);
  });
  const close = () => { client.destroy(); backend.destroy(); };
  client.on('error', close); backend.on('error', close); client.on('close', () => backend.destroy());
  backend.on('close', () => client.destroy());
}

function waitForBackend(callback, attempts = 100) {
  if (fs.existsSync(backendSocket)) { callback(); return; }
  if (attempts <= 0) process.exit(1);
  setTimeout(() => waitForBackend(callback, attempts - 1), 50);
}

fs.mkdirSync(controlDir, { recursive: true, mode: 0o700 });
fs.mkdirSync(path.dirname(backendSocket), { recursive: true });
spawnSync('/bin/launchctl', ['setenv', 'CODEX_APP_SERVER_USE_LOCAL_DAEMON', '1']);
removeSocket(frontSocket);
removeSocket(backendSocket);
const codex = codexCandidates.find(fs.existsSync);
if (!codex) process.exit(1);
const child = spawn(codex, ['app-server', '--enable', 'default_mode_request_user_input',
  '--listen', `unix://${backendSocket}`], { stdio: 'ignore' });
child.on('exit', () => process.exit(1));
waitForBackend(() => {
  const server = net.createServer(proxyConnection);
  server.listen(frontSocket, () => { try { fs.chmodSync(frontSocket, 0o600); } catch {} });
  const shutdown = () => { server.close(); child.kill(); removeSocket(frontSocket); removeSocket(backendSocket); };
  process.on('SIGTERM', shutdown); process.on('SIGINT', shutdown);
});
